# VSInstruments
This mod add instruments to Vintage Story. 
These intruments play .abc files, similarly to games LOTRO and Starbound. 

TODO add usage instructions
